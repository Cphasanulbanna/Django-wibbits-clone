from multiprocessing import context
from django.shortcuts import render, redirect
from django.urls import reverse

import json

from web.models import Brand, Subscribers, Feature, Video, Testimonial, MarketingFeature, Products, Blogs
from django.http.response import HttpResponse


def index(request):
    Brands = Brand.objects.all()
    Features = Feature.objects.all()
    Videos = Video.objects.all()
    Testimonials = Testimonial.objects.all()
    Marketing = MarketingFeature.objects.all()
    Product = Products.objects.all()
    Blog = Blogs.objects.all()
    
    context = {
        "brands": Brands,
         "features" : Features,
         "videos" : Videos,
         "testimonials" : Testimonials,
         "marketing" : Marketing,
         "products" : Product,
         "blogs" : Blog,
    }
    return render(request,"index.html",context=context)


def subscribers(request):
    email = request.POST.get("email")

    if not Subscribers.objects.filter(email=email).exists():

        Subscribers.objects.create(
            email = email
        )

        response_data = {
            "status": "success",
            "title": "Successfully Registered",
            "message": "You subscribed to our newsletter successfully."
        }

    else:
         response_data = {
            "status": "error",
            "title": "You are already  Registered",
            "message": "You are already a member."
        }

    return HttpResponse(json.dumps(response_data),content_type="application/javascript")

